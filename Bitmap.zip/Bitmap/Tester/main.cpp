#include "Bitmap_IO.h"
#include "BMP_Handler.h"

using namespace std;
using namespace bmp;

int main(int argc, char** argv) {
	system("pause");
	system("pause");
	return 0;
}